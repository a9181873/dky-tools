# TimesFM 真實交易資料行銷預測教學（可重跑）

本目錄是一個繁體中文、可在 Linux ARM64／Python 3.13 上重跑的時間序列教學。它使用 UCI Machine Learning Repository 的公開 **Online Retail** 真實交易資料，不使用合成資料、GA4 正式資料、CRM、PII、API key 或 token。UCI 說明此資料集涵蓋 2010-12-01 至 2011-12-09 的英國非店面零售交易，資料集有 541,909 筆資料，授權為 CC BY 4.0。[8]

教學的目的不是聲稱 TimesFM 能自動回答「某個廣告造成多少增量」，而是示範一個可稽核的需求／銷售 forecast：先定義 target，再以時間切分，和季節性基線比較，最後把預測結果轉成行銷規劃訊號。Forecast 與因果 uplift 的區別見「不要把 forecast 當 uplift」一節。

## 1. 先看可交付物與目前實跑狀態

重要的實跑輸出如下：

- `data/raw/metadata.json`：資料來源 URL、下載／驗證時間、授權、檔案大小與 SHA-256。
- `data/raw/online_retail.zip`：從 UCI 下載的原始公開壓縮檔；`data/raw/Online Retail.xlsx` 是解壓後檔案。
- `data/processed/daily_gross_sales.csv`：只含日粒度聚合值，不輸出 InvoiceNo、CustomerID、Description 或 Country。
- `outputs/forecast_holdout.csv`：28 天 holdout 的實際值與各模型預測。
- `outputs/metrics.json`：由程式計算的 MAE、RMSE、sMAPE、WAPE、TimesFM quantile coverage、環境版本與 provenance。
- `outputs/forecast_comparison.png`：由程式產生的比較圖。
- `scripts/download_data.py`、`scripts/run_forecast.py`、`scripts/smoke_test.py` 與 `tests/test_pipeline.py`：下載、建模、smoke test、單元測試。
- `timesfm-online-retail-tutorial-zhTW.ipynb`：繁體中文 Jupyter Notebook；逐格重跑資料檢查、chronological holdout、Seasonal Naive、ETS、四項指標、效果圖與尖峰敏感度檢查。

本次環境的 TimesFM 路徑已實際執行成功，不是以 baseline 數字冒充：

- Python `3.13.5`、Linux `aarch64`，無 CUDA；使用 PyTorch `2.12.0` CPU。
- `timesfm==3.0.2`，checkpoint `google/timesfm-3.0-pytorch`，呼叫 `timesfm3.TimesFM3Forecaster`。
- `outputs/metrics.json` 的 `timesfm.status` 為 `executed`、`device` 為 `cpu`。
- Hugging Face 未登入時會出現 unauthenticated rate-limit 警告；本教學沒有設定、讀取或寫入 HF token。checkpoint 會進本機 cache，故不把約 1.3 GB 的模型 cache 當作 artifact 提交。

若目前機器無法下載或載入 checkpoint，`--timesfm auto` 會把錯誤類型與訊息寫入 `metrics.json`，仍完成 CPU baseline；只有 `--timesfm required` 會讓命令失敗。這是失敗可見的 fallback，不會合成 TimesFM 數字。

### 1.1 用 Jupyter Notebook 閱讀與重跑

Notebook 預設只重跑不需大型權重的 Seasonal Naive 與 ETS，再讀取程式包內已驗證的 TimesFM 輸出；不會把既有輸出冒充成剛完成的新推論。請從本目錄啟動 Jupyter：

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-baseline.txt
.venv/bin/python -m pip install jupyterlab  # 本機沒有 Jupyter 時才需要
.venv/bin/jupyter lab
```

開啟 `timesfm-online-retail-tutorial-zhTW.ipynb` 後可由上而下執行。最後的 TimesFM 完整重跑 cell 預設為 `RUN_FULL_TIMESFM = False`；只有在安裝 `requirements-timesfm.txt`、閱讀 checkpoint 授權並明確改成 `True` 後，才會下載資料與模型，且輸出另存 `outputs/notebook_timesfm/`，不覆蓋附帶的驗證結果。

## 2. 問題定義、資料字典與 target

### 2.1 問題定義

給定截至預測起點前的每日交易聚合資料，預測接下來 28 天的每日 gross sales（英鎊）：

`y[t] = sum(Quantity[t, row] * UnitPrice[t, row])`

本實作只對 `Quantity > 0` 且 `UnitPrice > 0` 的列求和，因此 target 是「正向商品銷售毛額」，不是扣除退貨後的淨收入，也不是廣告增量。`Quantity <= 0` 的 cancellation／return 列被排除並在資料計數中保留排除筆數；不應把這個選擇誤稱為完整 demand。

此定義讓行銷團隊可以回答「未來 28 天可能有多少基準銷售額」，但不能回答「把預算增加 10% 會多多少銷售額」。後者需要 treatment、control 或其他可識別的因果設計。

### 2.2 原始與處理後資料字典

UCI 原始欄位定義以資料原始頁為準：[8]

| 欄位 | 原始意義 | 本教學用途 |
| --- | --- | --- |
| `InvoiceNo` | 交易／發票識別碼；以 `C` 開頭表示取消 | 只用來計算聚合筆數／交易數；不輸出到 processed CSV |
| `StockCode` | 商品識別碼 | 本版不做 SKU 預測 |
| `Description` | 商品名稱 | 不輸出，避免不必要的文字與識別資訊 |
| `Quantity` | 該筆交易數量 | 用於正向銷售篩選與 `sold_units` 聚合 |
| `InvoiceDate` | 交易產生日期時間 | 正規化到日粒度，作為時間索引 |
| `UnitPrice` | 單位英鎊價格 | 與 `Quantity` 相乘 |
| `CustomerID` | UCI 提供的客戶識別欄位 | 不使用、不輸出，不能拿來猜測個人行為 |
| `Country` | 客戶居住國家 | 本版不使用 |

處理後 `data/processed/daily_gross_sales.csv` 欄位為：

| 欄位 | 單位／定義 |
| --- | --- |
| `date` | 每日 UTC-naive calendar date；來源資料的日期欄位正規化，不是即時事件時間 |
| `gross_sales_gbp` | 符合正向銷售條件之 `Quantity * UnitPrice` 日總和 |
| `sold_units` | 符合條件列的 `Quantity` 日總和 |
| `invoice_count` | 正向銷售列的 distinct `InvoiceNo` 數 |
| `source_row_count` | 正向銷售來源列數 |

完整日曆用 0 填補「沒有正向銷售列」的日子；這不是插值，也不是合成觀測值，而是對「當日沒有觀測到正向銷售」的明確資料契約。原始公開檔仍保留在 `data/raw/`，checksum 在 metadata 中。

## 3. 來源、授權、下載與 checksum

資料來源是 UCI Online Retail dataset page [8] 與其公開下載檔 [9]。本次實際執行時間為 `2026-09-19T15:32:21Z`，沒有帳號或登入要求。`data/raw/metadata.json` 是程式產生的 provenance，不是手填結果：

- archive `data/raw/online_retail.zip`：23,715,478 bytes；SHA-256 `f5385cbb54bbebf7196389109c6b0621faab0c304e3702548165e71c84aede8b`。
- extracted `data/raw/Online Retail.xlsx`：23,715,344 bytes；SHA-256 `43465a06f2ccf7c8b5bd2892bc7defb52f97487934fe93b16ae4c3936424676d`。
- UCI 授權：Creative Commons Attribution 4.0 International（CC BY 4.0）；重用時仍應附上 UCI 與 Chen 的 attribution。[8]
- 引用：Chen, D. (2015). *Online Retail* [Dataset]. UCI Machine Learning Repository. DOI `10.24432/C5BW33`。[8]

重新下載並驗證：

```bash
.venv/bin/python scripts/download_data.py --force
```

`--force` 會重抓、解壓、重新計算 SHA-256；不接受 cookie、帳號或 API key。若下載失敗，命令會以非零狀態結束，不能把舊檔或合成資料當成新下載成功。

## 4. 時間切分、forecast horizon 與防 leakage

本次正式輸出使用明確的 chronological holdout，而不是 random split：

| 區段 | 日期 | 筆數／用途 |
| --- | --- | --- |
| train | 2010-12-01 至 2011-11-11 | 346 個每日觀測，所有模型只看這段 |
| holdout | 2011-11-12 至 2011-12-09 | 28 天、forecast horizon = 28 |
| 完整 reindex 日曆 | 2010-12-01 至 2011-12-09 | 374 天，其中 69 天 gross sales 為 0 |

防 leakage 規則：

1. 切分點在任何模型 fit、任何 normalization、任何超參數決定之前。
2. Seasonal Naive 只重複 train 最後 7 天；ETS 只用 train fit；TimesFM 只把 train target 傳入 `predict`。
3. holdout 實際值只用於評估，不可回填至 context，也不可選模型後再改切分。
4. 預測時可用的 covariate 必須在預測發佈時間已知。實際 clicks、sessions、revenue、orders、conversions 若是 holdout 期間事後才產生，不能作為 holdout input。
5. 對 GA4／CRM 的正式資料只可在隔離且授權的資料流程中使用；本 artifact 沒有匯入任何正式 GA4、CRM 或 PII。

這次是單一 28 天 holdout，不是 rolling-origin 全面穩健性檢驗；因此表格結論只能描述這一個預先指定的 holdout。若要上線評估，應再加多個 rolling origins、節慶切點與不同 horizon。

## 5. 模型與 TimesFM 版本／權重授權

### 5.1 CPU baseline

- **Seasonal Naive(7)**：以每週季節性為假設，將 train 最後 7 個值週期性重複 28 次。它是低複雜度、容易解釋的需求基線。
- **ETS**：`statsmodels` 的 additive trend + damped trend + additive weekly seasonality，`seasonal_periods=7`，只用 train fit。這裡不使用任何未來 regressors。

### 5.2 TimesFM 3.0 實作

Google Research 官方 README 將 TimesFM 定義為預訓練時間序列 foundation model，並標示 3.0 為最新模型；2.5 的程式仍在主線，1.0／2.0 的相關程式則歸檔於 `v1`。[1] 官方 pyproject 在本次抓取時顯示套件版本 `3.0.2`、Python `>=3.10`，核心依賴含 `numpy`、`huggingface_hub`、`safetensors`，PyTorch 為 optional extra。[2]

本次實跑路徑：

```python
from timesfm3 import TimesFM3Forecaster

forecaster = TimesFM3Forecaster.from_pretrained(
    "google/timesfm-3.0-pytorch",
    device="cpu",
    per_core_batch_size=1,
)
output = forecaster.predict(
    train_values.astype("float32"),
    horizon=28,
    return_quantiles=True,
    make_positive=True,
    sort_quantiles=True,
    use_znorm=False,
    padding_mode="none",
)
```

官方 checkpoint model card 說明 `google/timesfm-3.0-pytorch` 是 PyTorch weights/configuration，約 0.3B parameters、F32，並列出 32 的 context patch、64 的 forecast patch 與 9 個 quantile。[4] 本教學沒有把 checkpoint 二進位檔納入 artifact；重新執行時由 Hugging Face 下載到本機 cache，版本與 repo id 會寫入 `metrics.json`。

授權邊界不能省略：TimesFM source code 是 Apache-2.0，但官方 README 明確區分 2.5 以前的 weights 與 3.0 weights；3.0 pretrained weights 暫以 `timesfm-non-commercial-license-v1.0` 發佈，限制 non-commercial、non-production use。[1]
3.0 checkpoint 的 model card 與授權全文也標示為 TimesFM Non-Commercial License v1.0。[4][5]
因此本教學只作研究／教學／內部 benchmark，不代表可直接用於商業或 production。若要使用 2.5／2.0，仍須逐一閱讀所選 checkpoint 的 model card／license；官方 README 指出 2.5 weights 仍在 Apache-2.0 範圍。[1][6]
2.x 舊程式的載入方式也不同。[1]

TimesFM 的初始論文是 decoder-only、patched-decoder style 的 time-series foundation model，討論零樣本預測與不同 history／prediction length／granularity。[3] 論文與目前 3.0 程式、checkpoint 是不同版本層次；本文件不把論文結果當成此資料集的實測結果。

若 ARM64／CPU 或網路環境不能完成 checkpoint：

```bash
# 仍可完整產生資料、Seasonal Naive、ETS、metrics、CSV 與圖
.venv/bin/python scripts/run_forecast.py --horizon 28 --holdout 28 --timesfm off

# 必須成功使用 TimesFM 時，失敗要明確 exit non-zero
.venv/bin/python scripts/run_forecast.py --horizon 28 --holdout 28 --timesfm required
```

## 6. 實際評估結果（程式產生）

`outputs/metrics.json` 在本次實跑中的模型 metrics 如下；沒有手填：

| model | MAE | RMSE | sMAPE | WAPE |
| --- | ---: | ---: | ---: | ---: |
| Seasonal Naive(7) | 15,184.71 | 30,914.67 | 21.51% | 27.12% |
| ETS | 17,457.94 | 31,568.15 | 49.47% | 31.18% |
| TimesFM 3.0 CPU | 15,833.95 | 33,164.46 | 49.56% | 28.28% |

TimesFM 3.0 也實際回傳 quantiles；以 q10 至 q90 當作名義 80% 區間，28 天 holdout coverage 為 `0.8571428571`，平均區間寬度為 `38,005.06 GBP`。coverage 不是保證，且只有 28 個 holdout 點，不能拿來宣稱已完成校準。

本 holdout 的簡短判讀：Seasonal Naive 在四個點預測指標都優於本次 ETS 與 TimesFM 3.0，故若只根據這個 holdout 做 baseline 選擇，應先保留 Seasonal Naive 作為 champion，再用更多 rolling origins 驗證，而不是因為 TimesFM 是 foundation model 就強行採用。TimesFM 的預測區間可作為風險範圍參考，但不能取代基線比較或業務校準。

圖與逐日值：

- `outputs/forecast_comparison.png`：訓練尾端、實際 holdout、三模型 forecast。
- `outputs/forecast_holdout.csv`：`date`、`actual_gross_sales_gbp`、`seasonal_naive_7`、`ets`、`timesfm_3_point`，若 quantile 成功另含 `timesfm_3_q10/q50/q90`。

## 7. 行銷 covariates／語意特徵的安全擴充方式

本版刻意只使用交易 target，讓資料切分與模型差異先清楚。TimesFM 官方 README 描述 3.0 可支援 multivariate 與 past-only／past-and-future covariates；2.5 的官方 skill 也描述以 XReg 方式加入 exogenous regressors。[1][7] 以下是可在隔離資料環境中實作的欄位契約，不是本次已在正式 GA4／CRM 上驗證的結果：

| 來源 | 可映射的日粒度欄位（示例） | 何時可用 | leakage 風險 |
| --- | --- | --- | --- |
| GA4 | `date`, `sessions`, `engaged_sessions`, `conversions`, `device_category`, `source_medium`, `campaign_id` | 已結算且在 forecast origin 前到達的資料；future calendar／已排程活動可事前建立 | holdout 期間事後才完成的 sessions、conversions、revenue 不能當未來已知 covariate；campaign 名稱可能在歸因回補後改變 |
| CRM | `date`, `lead_count`, `opportunity_count`, `lifecycle_stage_counts`, `segment_key` | 只用匿名、聚合、已授權且在 origin 前可見的數量 | customer-level PII、事後更新的 stage、把 holdout conversion 當 input 都會泄漏；本教學不匯入 CRM |
| Ads | `date`, `planned_spend`, `planned_impressions`, `actual_spend`, `clicks`, `campaign_id` | 未來已核准的 budget／calendar 可作 future-known；actual metrics 只作 past-only | 用 holdout actual clicks／spend 會看見答案的一部分；planned 與 actual 必須分欄 |
| 語意／活動日曆 | `promotion_type`, `holiday_flag`, `channel`, `product_category`, `campaign_theme` | 在 origin 前已排程或由歷史資料生成的固定 taxonomy | 事後命名、事後分類或用結果欄位產出的 embedding 會回看未來；應固定字典版本 |

實務上可把 GA4／CRM 的來源欄位先聚合到「date × channel/campaign」並做 join audit：每一列記錄 `observed_at`、`forecast_origin`、`is_future_known`。任何 `observed_at > forecast_origin` 的實際結果欄位只能放在 label／監控，不可進 forecast input。正式資料的 PII、email、電話、原始 client identifier、access token、API key 不得進這個公開教學或任何 artifact。

## 8. 不要把 forecast 當 uplift

- **Forecast**：在既有歷史、季節性與可用 covariates 下估計 `E[Y_future | information_at_origin]`。本教學的 TimesFM、ETS、Seasonal Naive 都是此類預測器。
- **Causal effect／uplift**：需要比較 treatment 與 counterfactual，例如 `E[Y | campaign=on] - E[Y | campaign=off]`，並處理隨機化、分群、confounding、持續時間、attribution window 與 interference。
- 本次 holdout 上看到銷售上升，不等於廣告造成上升；節慶、供貨、價格、自然流量與資料回補都可能同時變動。
- 可以把 forecast 當作 budget planning 的 baseline，然後另建 geo／audience holdout 或增量實驗估 uplift；不可用 TimesFM 的點預測直接宣稱 ROAS 增量。

## 9. 安裝、執行與驗證

### 9.1 建立環境

這台主機是 PEP 668 externally-managed Python，因此先用 venv；不使用 `--break-system-packages`：

```bash
python3 -m venv --system-site-packages .venv
.venv/bin/python -m pip install -r requirements-baseline.txt
# 若主機有可用的 ARM64 PyTorch wheel，再安裝 TimesFM 路徑
.venv/bin/python -m pip install 'timesfm[torch]==3.0.2'
```

`requirements.txt` 是完整清單；`requirements-baseline.txt` 讓不能下載／載入 checkpoint 的機器仍可重跑 CPU baseline；`requirements-timesfm.txt` 是 baseline 加上 TimesFM optional extra。套件版本與本次實際環境也寫入 `outputs/metrics.json`。

### 9.2 下載、smoke test、完整實跑

```bash
# 1. 下載公開資料並建立 provenance/checksum
.venv/bin/python scripts/download_data.py --force

# 2. 三個快速單元測試
.venv/bin/python -m unittest discover -s tests -v

# 3. CPU-only smoke test，7 天小 holdout，明確跳過模型下載
.venv/bin/python scripts/smoke_test.py

# 4. 正式 28 天 holdout；會使用已安裝的 TimesFM 3.0 CPU checkpoint
.venv/bin/python scripts/run_forecast.py --horizon 28 --holdout 28 --timesfm auto
```

本次驗證命令的真實結果：

- `py_compile scripts/download_data.py scripts/run_forecast.py`：exit 0。
- `python -m unittest discover -s tests -v`：3 tests，`OK`。
- `python scripts/smoke_test.py`：exit 0，確認 metrics、CSV、PNG 均存在且 baseline metrics 不為空。
- `python scripts/run_forecast.py --horizon 28 --holdout 28 --timesfm auto`：exit 0；TimesFM status `executed`，資料與模型 metrics 已寫入 `outputs/metrics.json`。

## 10. 已知限制與未重跑部分

- 本次是單一明確時間 holdout；未聲稱已完成多 origin rolling evaluation、校準後 prediction interval 或 production load test。
- 本次未用真實 GA4／CRM／廣告資料，也未驗證任何正式資料欄位映射；第 7 節是隔離環境的擴充契約。
- 3.0 checkpoint license 是 non-commercial／non-production；不可把這份 CPU 教學當成商業部署授權。
- `master` README 與 Hugging Face model card 是會更新的外部頁面；本次的實際套件版本、資料 checksum、checkpoint repo id、下載時間都保存在本目錄的 metrics／metadata。若未來來源頁改版，應重新下載、重算 checksum、重跑所有 metrics，再更新文件。
- 交易資料只有約一年，且有零銷售日與節慶尾端；對其他市場、GA4 conversion、CRM pipeline、廣告 spend，不應直接外推本次誤差。

## Sources

[1] https://raw.githubusercontent.com/google-research/timesfm/master/README.md
[2] https://raw.githubusercontent.com/google-research/timesfm/master/pyproject.toml
[3] https://arxiv.org/abs/2310.10688
[4] https://huggingface.co/google/timesfm-3.0-pytorch
[5] https://huggingface.co/google/timesfm-3.0-pytorch/raw/main/LICENSE
[6] https://huggingface.co/google/timesfm-2.5-200m-pytorch
[7] https://github.com/google-research/timesfm/blob/master/timesfm-forecasting/SKILL.md
[8] https://archive.ics.uci.edu/dataset/352/online+retail
[9] https://archive.ics.uci.edu/static/public/352/online+retail.zip
