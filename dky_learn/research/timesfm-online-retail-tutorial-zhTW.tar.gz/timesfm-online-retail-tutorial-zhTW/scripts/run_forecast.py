#!/usr/bin/env python3
"""Run a leakage-safe daily revenue forecast on UCI Online Retail.

The target is gross item value (GBP) on rows with Quantity > 0 and UnitPrice > 0.
Cancellation rows are not silently mixed into the target; they are documented as
an excluded event type.  The script always runs CPU baselines.  TimesFM 3.0 is
attempted when --timesfm=auto (the default), and failures are recorded honestly
in metrics.json rather than replaced by made-up predictions.
"""
from __future__ import annotations

import argparse
import importlib.metadata
import json
import math
import os
import platform
import sys
import traceback
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


@dataclass
class TimesFMResult:
    status: str
    checkpoint: str
    package_version: str | None = None
    device: str = "cpu"
    error_type: str | None = None
    error: str | None = None
    point: np.ndarray | None = None
    quantiles: np.ndarray | None = None


def resolve_path(repo_root: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else repo_root / path


def load_provenance(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"dataset metadata not found: {path}; run download_data.py first")
    return json.loads(path.read_text(encoding="utf-8"))


def aggregate_transactions(raw_path: Path) -> tuple[pd.DataFrame, dict[str, int]]:
    frame = pd.read_excel(raw_path, engine="openpyxl")
    required = {"InvoiceNo", "Quantity", "InvoiceDate", "UnitPrice"}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"UCI file is missing required columns: {missing}")

    frame["InvoiceDate"] = pd.to_datetime(frame["InvoiceDate"], dayfirst=True, errors="coerce")
    frame["Quantity"] = pd.to_numeric(frame["Quantity"], errors="coerce")
    frame["UnitPrice"] = pd.to_numeric(frame["UnitPrice"], errors="coerce")
    frame = frame.dropna(subset=["InvoiceDate", "Quantity", "UnitPrice"]).copy()
    frame["line_value_gbp"] = frame["Quantity"] * frame["UnitPrice"]
    frame["date"] = frame["InvoiceDate"].dt.normalize()

    sale_mask = (frame["Quantity"] > 0) & (frame["UnitPrice"] > 0)
    sales = frame.loc[sale_mask].copy()
    if sales.empty:
        raise ValueError("no positive sales rows remained after validation")

    daily = (
        sales.groupby("date", sort=True)
        .agg(
            gross_sales_gbp=("line_value_gbp", "sum"),
            sold_units=("Quantity", "sum"),
            invoice_count=("InvoiceNo", "nunique"),
            source_row_count=("InvoiceNo", "size"),
        )
        .sort_index()
    )
    full_index = pd.date_range(daily.index.min(), daily.index.max(), freq="D", name="date")
    daily = daily.reindex(full_index, fill_value=0)
    daily["gross_sales_gbp"] = daily["gross_sales_gbp"].astype(float)
    daily["sold_units"] = daily["sold_units"].astype(float)
    daily["invoice_count"] = daily["invoice_count"].astype(int)
    daily["source_row_count"] = daily["source_row_count"].astype(int)

    counts = {
        "raw_rows_read": int(len(frame)),
        "positive_sale_rows": int(sale_mask.loc[frame.index].sum()),
        "excluded_nonpositive_rows": int((~sale_mask.loc[frame.index]).sum()),
        "daily_rows_after_reindex": int(len(daily)),
        "zero_sales_days_after_reindex": int((daily["gross_sales_gbp"] == 0).sum()),
    }
    return daily, counts


def seasonal_naive(train: np.ndarray, horizon: int, period: int = 7) -> np.ndarray:
    if train.size < period:
        raise ValueError(f"seasonal naive needs at least {period} observations")
    return np.resize(train[-period:], horizon).astype(float)


def ets_forecast(train: np.ndarray, horizon: int, period: int = 7) -> np.ndarray:
    from statsmodels.tsa.holtwinters import ExponentialSmoothing

    model = ExponentialSmoothing(
        train,
        trend="add",
        damped_trend=True,
        seasonal="add",
        seasonal_periods=period,
        initialization_method="estimated",
    )
    fitted = model.fit(optimized=True, use_brute=False)
    return np.asarray(fitted.forecast(horizon), dtype=float)


def metric_values(actual: np.ndarray, predicted: np.ndarray) -> dict[str, float]:
    actual = np.asarray(actual, dtype=float)
    predicted = np.asarray(predicted, dtype=float)
    error = predicted - actual
    denominator = np.abs(actual) + np.abs(predicted)
    smape_terms = np.divide(
        2.0 * np.abs(error), denominator, out=np.zeros_like(error), where=denominator != 0
    )
    actual_total = float(np.abs(actual).sum())
    return {
        "mae": float(np.mean(np.abs(error))),
        "rmse": float(np.sqrt(np.mean(error**2))),
        "smape": float(100.0 * np.mean(smape_terms)),
        "wape": float(100.0 * np.abs(error).sum() / actual_total)
        if actual_total != 0
        else 0.0,
    }


def interval_values(actual: np.ndarray, lower: np.ndarray, upper: np.ndarray) -> dict[str, float]:
    actual = np.asarray(actual, dtype=float)
    lower = np.asarray(lower, dtype=float)
    upper = np.asarray(upper, dtype=float)
    return {
        "coverage_80pct_nominal": float(np.mean((actual >= lower) & (actual <= upper))),
        "mean_interval_width": float(np.mean(upper - lower)),
    }


def package_version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def run_timesfm(
    train: np.ndarray,
    horizon: int,
    mode: str,
    checkpoint: str,
    cache_dir: Path,
) -> TimesFMResult:
    base = TimesFMResult(status="skipped", checkpoint=checkpoint)
    if mode == "off":
        base.error = "disabled by --timesfm=off"
        return base

    base.package_version = package_version("timesfm")
    try:
        from timesfm3 import TimesFM3Forecaster

        cache_dir.mkdir(parents=True, exist_ok=True)
        forecaster = TimesFM3Forecaster.from_pretrained(
            checkpoint,
            device="cpu",
            per_core_batch_size=1,
            cache_dir=str(cache_dir),
        )
        output = forecaster.predict(
            np.asarray(train, dtype=np.float32),
            horizon=horizon,
            return_quantiles=True,
            make_positive=True,
            sort_quantiles=True,
            use_znorm=False,
            padding_mode="none",
        )
        point = np.asarray(output.forecast, dtype=float).reshape(-1)[:horizon]
        quantiles = None
        if output.quantiles is not None:
            quantiles = np.asarray(output.quantiles, dtype=float)
            if quantiles.ndim == 1:
                quantiles = quantiles.reshape(-1, 1)
            quantiles = quantiles[:horizon]
        if point.size != horizon or not np.isfinite(point).all():
            raise ValueError(f"TimesFM returned invalid point forecast shape={point.shape}")
        base.status = "executed"
        base.point = point
        base.quantiles = quantiles
        return base
    except Exception as exc:  # an honest fallback is part of this tutorial
        base.status = "failed"
        base.error_type = type(exc).__name__
        base.error = " ".join(str(exc).split())[:1000]
        if mode == "required":
            raise RuntimeError(
                f"TimesFM execution failed ({base.error_type}): {base.error}\n"
                + traceback.format_exc()
            ) from exc
        return base


def serialize_timesfm(result: TimesFMResult) -> dict[str, Any]:
    return {
        "status": result.status,
        "checkpoint": result.checkpoint,
        "package_version": result.package_version,
        "device": result.device,
        "error_type": result.error_type,
        "error": result.error,
        "weights_license": "TimesFM Non-Commercial License v1.0 (3.0 checkpoint)",
        "weights_license_url": "https://huggingface.co/google/timesfm-3.0-pytorch/raw/main/LICENSE",
    }


def build_environment() -> dict[str, Any]:
    return {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "machine": platform.machine(),
        "numpy": package_version("numpy"),
        "pandas": package_version("pandas"),
        "openpyxl": package_version("openpyxl"),
        "scipy": package_version("scipy"),
        "statsmodels": package_version("statsmodels"),
        "matplotlib": package_version("matplotlib"),
        "huggingface_hub": package_version("huggingface_hub"),
        "safetensors": package_version("safetensors"),
        "timesfm": package_version("timesfm"),
        "torch": package_version("torch"),
    }


def write_plot(
    output_path: Path,
    train: pd.Series,
    test: pd.Series,
    forecasts: dict[str, np.ndarray],
) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(12, 5))
    history_window = min(len(train), 120)
    ax.plot(train.index[-history_window:], train.to_numpy()[-history_window:], label="training data", color="#345995")
    ax.plot(test.index, test.to_numpy(), label="actual holdout", color="#111111", linewidth=2)
    colors = {"seasonal_naive": "#e76f51", "ets": "#2a9d8f", "timesfm_3": "#8e44ad"}
    labels = {"seasonal_naive": "Seasonal Naive(7)", "ets": "ETS", "timesfm_3": "TimesFM 3.0"}
    for name, values in forecasts.items():
        if np.isfinite(values).all():
            ax.plot(test.index, values, label=labels.get(name, name), color=colors.get(name), linestyle="--")
    ax.axvline(test.index[0], color="#777777", linestyle=":", linewidth=1)
    # Keep the artifact portable across minimal Linux images that do not ship
    # CJK fonts; the accompanying tutorial is the Traditional Chinese label.
    ax.set_title("UCI Online Retail: daily gross sales forecast (executed output)")
    ax.set_ylabel("gross sales (GBP)")
    ax.grid(alpha=0.25)
    ax.legend(loc="upper left")
    fig.tight_layout()
    fig.savefig(output_path, dpi=140)
    plt.close(fig)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-file", default="data/raw/Online Retail.xlsx")
    parser.add_argument("--metadata", default="data/raw/metadata.json")
    parser.add_argument("--output-dir", default="outputs")
    parser.add_argument("--horizon", type=int, default=28)
    parser.add_argument("--holdout", type=int, default=None)
    parser.add_argument("--seasonal-period", type=int, default=7)
    parser.add_argument("--timesfm", choices=["auto", "off", "required"], default="auto")
    parser.add_argument("--timesfm-checkpoint", default="google/timesfm-3.0-pytorch")
    parser.add_argument("--model-cache-dir", default="data/model_cache")
    args = parser.parse_args()
    if args.horizon <= 0:
        raise ValueError("--horizon must be positive")
    holdout = args.holdout if args.holdout is not None else args.horizon
    if holdout != args.horizon:
        raise ValueError("this tutorial keeps holdout length equal to forecast horizon")

    repo_root = Path(__file__).resolve().parents[1]
    raw_file = resolve_path(repo_root, args.raw_file)
    metadata_file = resolve_path(repo_root, args.metadata)
    output_dir = resolve_path(repo_root, args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    provenance = load_provenance(metadata_file)
    daily, data_counts = aggregate_transactions(raw_file)
    processed_path = repo_root / "data" / "processed" / "daily_gross_sales.csv"
    processed_path.parent.mkdir(parents=True, exist_ok=True)
    processed = daily.reset_index()
    processed["date"] = processed["date"].dt.strftime("%Y-%m-%d")
    processed.to_csv(processed_path, index=False)

    if len(daily) <= holdout + args.seasonal_period:
        raise ValueError(f"not enough daily observations: {len(daily)}")
    train = daily.iloc[:-holdout]
    test = daily.iloc[-holdout:]
    target_train = train["gross_sales_gbp"].to_numpy(dtype=float)
    target_test = test["gross_sales_gbp"].to_numpy(dtype=float)

    naive = seasonal_naive(target_train, holdout, args.seasonal_period)
    ets = ets_forecast(target_train, holdout, args.seasonal_period)
    timesfm = run_timesfm(
        target_train,
        holdout,
        args.timesfm,
        args.timesfm_checkpoint,
        resolve_path(repo_root, args.model_cache_dir),
    )

    model_forecasts: dict[str, np.ndarray] = {
        "seasonal_naive": naive,
        "ets": ets,
        "timesfm_3": timesfm.point
        if timesfm.point is not None
        else np.full(holdout, np.nan, dtype=float),
    }
    metrics: dict[str, Any] = {
        name: metric_values(target_test, forecast)
        for name, forecast in model_forecasts.items()
        if np.isfinite(forecast).all()
    }
    if timesfm.quantiles is not None and timesfm.quantiles.shape[1] >= 2:
        metrics["timesfm_3_interval"] = interval_values(
            target_test, timesfm.quantiles[:, 0], timesfm.quantiles[:, -1]
        )

    result = pd.DataFrame(
        {
            "date": test.index.strftime("%Y-%m-%d"),
            "actual_gross_sales_gbp": target_test,
            "seasonal_naive_7": naive,
            "ets": ets,
            "timesfm_3_point": model_forecasts["timesfm_3"],
        }
    )
    if timesfm.quantiles is not None and timesfm.quantiles.shape[1] >= 9:
        result["timesfm_3_q10"] = timesfm.quantiles[:, 0]
        result["timesfm_3_q50"] = timesfm.quantiles[:, 4]
        result["timesfm_3_q90"] = timesfm.quantiles[:, 8]
    forecast_csv = output_dir / "forecast_holdout.csv"
    result.to_csv(forecast_csv, index=False)

    plot_path = output_dir / "forecast_comparison.png"
    write_plot(plot_path, train["gross_sales_gbp"], test["gross_sales_gbp"], model_forecasts)

    metrics_payload: dict[str, Any] = {
        "schema_version": 1,
        "generated_at_utc": pd.Timestamp.now(tz="UTC").isoformat(),
        "target": {
            "name": "gross_sales_gbp",
            "definition": "sum(Quantity * UnitPrice) for rows with Quantity > 0 and UnitPrice > 0",
            "unit": "GBP per day",
            "frequency": "D",
            "seasonal_period": args.seasonal_period,
        },
        "split": {
            "method": "time_holdout",
            "train_start": train.index.min().strftime("%Y-%m-%d"),
            "train_end": train.index.max().strftime("%Y-%m-%d"),
            "holdout_start": test.index.min().strftime("%Y-%m-%d"),
            "holdout_end": test.index.max().strftime("%Y-%m-%d"),
            "forecast_horizon": holdout,
            "leakage_rule": "all model fits use only rows before holdout_start",
        },
        "data_provenance": provenance,
        "data_counts": data_counts,
        "models": metrics,
        "timesfm": serialize_timesfm(timesfm),
        "environment": build_environment(),
        "artifacts": {
            "processed_csv": str(processed_path.relative_to(repo_root)),
            "forecast_csv": str(forecast_csv.relative_to(repo_root)),
            "plot": str(plot_path.relative_to(repo_root)),
        },
    }
    metrics_path = output_dir / "metrics.json"
    metrics_path.write_text(
        json.dumps(metrics_payload, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(metrics_payload, ensure_ascii=False, indent=2, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
