#!/usr/bin/env python3
"""Run the fast, deterministic CPU-only smoke test for the tutorial."""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="outputs/smoke")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output_dir = Path(args.output_dir)
    if not output_dir.is_absolute():
        output_dir = root / output_dir
    command = [
        sys.executable,
        str(root / "scripts" / "run_forecast.py"),
        "--horizon",
        "7",
        "--holdout",
        "7",
        "--timesfm",
        "off",
        "--output-dir",
        str(output_dir),
    ]
    completed = subprocess.run(command, cwd=root, check=False, text=True)
    if completed.returncode != 0:
        raise SystemExit(completed.returncode)
    metrics_path = output_dir / "metrics.json"
    forecast_path = output_dir / "forecast_holdout.csv"
    plot_path = output_dir / "forecast_comparison.png"
    for path in (metrics_path, forecast_path, plot_path):
        if not path.is_file() or path.stat().st_size == 0:
            raise AssertionError(f"smoke output missing or empty: {path}")
    metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
    if metrics["timesfm"]["status"] != "skipped":
        raise AssertionError("smoke test must make its TimesFM skip explicit")
    if set(("seasonal_naive", "ets")) - set(metrics["models"]):
        raise AssertionError("CPU baseline metrics are incomplete")
    print(f"smoke test passed: {metrics_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
