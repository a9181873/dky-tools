#!/usr/bin/env python3
"""Download and verify the public UCI Online Retail dataset.

The script intentionally downloads only the public source.  It never accepts
credentials and it writes aggregate-safe provenance metadata next to the raw
archive.  Run from the repository root:

    .venv/bin/python scripts/download_data.py --force
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path

SOURCE_URL = "https://archive.ics.uci.edu/static/public/352/online+retail.zip"
DATASET_PAGE = "https://archive.ics.uci.edu/dataset/352/online+retail"
LICENSE_URL = "https://creativecommons.org/licenses/by/4.0/legalcode"
EXPECTED_MEMBER = "Online Retail.xlsx"


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def download(url: str, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    partial = destination.with_suffix(destination.suffix + ".part")
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "timesfm-marketing-forecasting-tutorial/1.0"},
    )
    try:
        with urllib.request.urlopen(request, timeout=180) as response, partial.open("wb") as out:
            shutil.copyfileobj(response, out, length=1024 * 1024)
        partial.replace(destination)
    finally:
        if partial.exists():
            partial.unlink()


def extract_verified(archive: Path, raw_dir: Path) -> Path:
    with zipfile.ZipFile(archive) as zf:
        names = zf.namelist()
        if EXPECTED_MEMBER not in names:
            raise RuntimeError(f"archive missing {EXPECTED_MEMBER!r}; members={names!r}")
        # The UCI archive has a single flat member.  Reject path traversal if
        # the upstream archive ever changes.
        member_path = Path(EXPECTED_MEMBER)
        if member_path.is_absolute() or ".." in member_path.parts:
            raise RuntimeError("unsafe archive member")
        zf.extract(EXPECTED_MEMBER, raw_dir)
    extracted = raw_dir / EXPECTED_MEMBER
    if not extracted.is_file() or extracted.stat().st_size == 0:
        raise RuntimeError(f"extraction did not produce a non-empty file: {extracted}")
    return extracted


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, default=Path("data/raw"))
    parser.add_argument("--force", action="store_true", help="download the archive again")
    args = parser.parse_args()

    raw_dir = args.out_dir
    archive = raw_dir / "online_retail.zip"
    extracted = raw_dir / EXPECTED_MEMBER
    metadata_path = raw_dir / "metadata.json"
    previous: dict[str, object] = {}
    if metadata_path.exists():
        try:
            previous = json.loads(metadata_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            previous = {}

    downloaded_at = previous.get("downloaded_at_utc")
    if args.force or not archive.exists():
        print(f"Downloading {SOURCE_URL}")
        download(SOURCE_URL, archive)
        downloaded_at = utc_now()
    elif not archive.is_file():
        raise RuntimeError(f"archive path is not a regular file: {archive}")

    archive_hash = sha256(archive)
    if not extracted.exists() or args.force:
        print(f"Extracting {EXPECTED_MEMBER}")
        extracted = extract_verified(archive, raw_dir)
    extracted_hash = sha256(extracted)

    metadata = {
        "dataset": "UCI Online Retail",
        "dataset_id": 352,
        "source_url": SOURCE_URL,
        "dataset_page": DATASET_PAGE,
        "citation": "Chen, D. (2015). Online Retail [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5BW33.",
        "license": "Creative Commons Attribution 4.0 International (CC BY 4.0)",
        "license_url": LICENSE_URL,
        "downloaded_at_utc": downloaded_at,
        "verified_at_utc": utc_now(),
        "archive": {
            "relative_path": str(archive),
            "size_bytes": archive.stat().st_size,
            "sha256": archive_hash,
        },
        "extracted_file": {
            "relative_path": str(extracted),
            "size_bytes": extracted.stat().st_size,
            "sha256": extracted_hash,
        },
        "expected_archive_member": EXPECTED_MEMBER,
        "account_required": False,
        "contains_synthetic_data": False,
        "contains_ga4_crm_pii_or_secrets": False,
    }
    metadata_path.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
