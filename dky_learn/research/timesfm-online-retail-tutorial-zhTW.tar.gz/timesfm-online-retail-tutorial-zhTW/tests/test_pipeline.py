from __future__ import annotations

import unittest

import numpy as np

from scripts.run_forecast import metric_values, seasonal_naive


class PipelineUnitTests(unittest.TestCase):
    def test_seasonal_naive_repeats_last_week(self) -> None:
        train = np.arange(1.0, 15.0)
        np.testing.assert_array_equal(
            seasonal_naive(train, horizon=10, period=7),
            np.array([8, 9, 10, 11, 12, 13, 14, 8, 9, 10], dtype=float),
        )

    def test_metrics_are_computed_from_predictions(self) -> None:
        actual = np.array([1.0, 2.0, 4.0])
        predicted = np.array([1.0, 3.0, 2.0])
        values = metric_values(actual, predicted)
        self.assertAlmostEqual(values["mae"], 1.0)
        self.assertAlmostEqual(values["rmse"], np.sqrt(5.0 / 3.0))
        self.assertGreater(values["smape"], 0.0)
        self.assertGreater(values["wape"], 0.0)

    def test_zero_smape_denominator_is_defined(self) -> None:
        values = metric_values(np.zeros(2), np.zeros(2))
        self.assertEqual(values["smape"], 0.0)
        self.assertEqual(values["wape"], 0.0)


if __name__ == "__main__":
    unittest.main()
