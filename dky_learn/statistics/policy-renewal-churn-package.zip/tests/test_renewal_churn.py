import unittest

from scripts.renewal_churn import (
    FEATURES,
    THRESHOLDS,
    choose_threshold,
    evaluate,
    fit_logistic_regression,
    fit_standardizer,
    generate_rows,
    predict_probabilities,
    split_rows,
    transform_rows,
)


class RenewalChurnTests(unittest.TestCase):
    def test_temporal_split_has_expected_sizes_and_month_boundaries(self):
        train, valid, test = split_rows(generate_rows())

        self.assertEqual((len(train), len(valid), len(test)), (180, 60, 60))
        self.assertEqual((train[0]["month"], train[-1]["month"]), (0, 5))
        self.assertEqual((valid[0]["month"], valid[-1]["month"]), (6, 7))
        self.assertEqual((test[0]["month"], test[-1]["month"]), (8, 9))

    def test_standardizer_uses_population_statistics_from_training_rows(self):
        train_rows = [
            {"premium_change": 1.0, "contacts_90d": 10.0, "tenure_years": 4.0},
            {"premium_change": 3.0, "contacts_90d": 30.0, "tenure_years": 8.0},
        ]
        means, stds = fit_standardizer(train_rows)

        self.assertEqual(means, [2.0, 20.0, 6.0])
        self.assertEqual(stds, [1.0, 10.0, 2.0])
        self.assertEqual(FEATURES, ("premium_change", "contacts_90d", "tenure_years"))

    def test_constant_training_feature_uses_unit_standard_deviation(self):
        rows = [
            {"premium_change": 0.1, "contacts_90d": 2, "tenure_years": 1.0},
            {"premium_change": 0.1, "contacts_90d": 2, "tenure_years": 3.0},
        ]

        _, stds = fit_standardizer(rows)

        self.assertEqual(stds, [1.0, 1.0, 1.0])

    def test_training_pipeline_returns_probabilities_in_unit_interval(self):
        rows = generate_rows()
        train, _, test = split_rows(rows)
        means, stds = fit_standardizer(train)
        scaled_train = transform_rows(train, means, stds)
        scaled_test = transform_rows(test, means, stds)
        bias, weights = fit_logistic_regression(scaled_train)

        probabilities = predict_probabilities(scaled_test, bias, weights)

        self.assertEqual(len(probabilities), 60)
        self.assertTrue(all(0.0 <= probability <= 1.0 for probability in probabilities))

    def test_threshold_candidates_and_ties_choose_the_higher_threshold(self):
        self.assertEqual(THRESHOLDS, [i / 100 for i in range(10, 91, 5)])

        threshold, _ = choose_threshold([0, 0], [0.05, 0.05])

        self.assertEqual(threshold, 0.9)

    def test_evaluation_reports_confusion_metrics_and_brier_score(self):
        result = evaluate([1, 0, 1, 0], [0.8, 0.7, 0.4, 0.1], 0.5)

        self.assertEqual(
            (result["tp"], result["fp"], result["fn"], result["tn"]),
            (1, 1, 1, 1),
        )
        self.assertAlmostEqual(result["precision"], 0.5)
        self.assertAlmostEqual(result["recall"], 0.5)
        self.assertAlmostEqual(result["f1"], 0.5)
        self.assertAlmostEqual(result["brier"], 0.225)


if __name__ == "__main__":
    unittest.main()
